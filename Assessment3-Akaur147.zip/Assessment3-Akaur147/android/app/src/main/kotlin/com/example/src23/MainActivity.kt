package com.example.src23

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
